package com.nextgen.player

import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.nextgen.player.databinding.ActivityPlayerBinding
import com.nextgen.player.engine.CodecInfo
import java.util.concurrent.TimeUnit

class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_FILE_PATH = "extra_file_path"
    }

    private lateinit var binding: ActivityPlayerBinding
    private val viewModel: PlayerViewModel by viewModels()

    private var controlsVisible = true
    private val hideRunnable = Runnable { hideControls() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Keep screen on during playback
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        makeFullscreen()

        val filePath = intent.getStringExtra(EXTRA_FILE_PATH) ?: run {
            Toast.makeText(this, "No file path supplied", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        binding.tvFileName.text = filePath.substringAfterLast('/')
        binding.tvFileType.text = CodecInfo.describeFile(filePath)

        setupControls()
        observeViewModel()

        viewModel.load(filePath)
    }

    // ── Controls ─────────────────────────────────────────────────────────────

    private fun setupControls() {
        binding.btnPlayPause.setOnClickListener { viewModel.togglePause() }

        binding.btnBack.setOnClickListener { finish() }

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val frac = progress / 1000.0
                    viewModel.seekTo(frac)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Tap surface to toggle controls
        binding.ivFrame.setOnClickListener { toggleControls() }
    }

    // ── Observers ────────────────────────────────────────────────────────────

    private fun observeViewModel() {
        viewModel.currentFrame.observe(this) { bmp ->
            bmp ?: return@observe
            binding.ivFrame.setImageBitmap(bmp)
        }

        viewModel.isPlaying.observe(this) { playing ->
            binding.btnPlayPause.setImageResource(
                if (playing) R.drawable.ic_pause else R.drawable.ic_play
            )
        }

        viewModel.progressFrac.observe(this) { frac ->
            binding.seekBar.progress = (frac * 1000).toInt().coerceIn(0, 1000)
            val posMs = (frac * viewModel.getDurationMs()).toLong()
            val durMs = viewModel.getDurationMs()
            binding.tvPosition.text = formatTime(posMs)
            binding.tvDuration.text = formatTime(durMs)
        }

        viewModel.errorMessage.observe(this) { err ->
            err ?: return@observe
            Toast.makeText(this, "Error: $err", Toast.LENGTH_LONG).show()
        }

        viewModel.playbackDone.observe(this) { done ->
            if (done) {
                binding.btnPlayPause.setImageResource(R.drawable.ic_play)
                showControls()
            }
        }
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private fun toggleControls() {
        if (controlsVisible) hideControls() else showControls()
    }

    private fun showControls() {
        controlsVisible = true
        binding.controlsOverlay.visibility = View.VISIBLE
        binding.topBar.visibility = View.VISIBLE
        binding.controlsOverlay.removeCallbacks(hideRunnable)
        binding.controlsOverlay.postDelayed(hideRunnable, 3500)
    }

    private fun hideControls() {
        controlsVisible = false
        binding.controlsOverlay.visibility = View.GONE
        binding.topBar.visibility = View.GONE
    }

    private fun makeFullscreen() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )
    }

    private fun formatTime(ms: Long): String {
        val h = TimeUnit.MILLISECONDS.toHours(ms)
        val m = TimeUnit.MILLISECONDS.toMinutes(ms) % 60
        val s = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }

    override fun onPause() {
        super.onPause()
        if (viewModel.isPlaying.value == true) viewModel.togglePause()
    }

    override fun onDestroy() {
        super.onDestroy()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}
