package com.nextgen.player.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import android.view.Surface
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.*
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * NextGenPlayer – FFmpeg-based engine for APV, VVC (H.266), and IAMF playback.
 *
 * Architecture:
 *  - Video: FFmpeg decodes to raw YUV/RGBA frames → piped as raw video pipe →
 *           rendered to SurfaceView via a Bitmap-based frame loop.
 *  - Audio: FFmpeg decodes to PCM s16le (IAMF/AAC/Opus/etc.) → Android AudioTrack.
 *
 * For APV: requires FFmpeg built with --enable-libapv (Samsung open-source decoder).
 * For VVC: requires FFmpeg built with --enable-libvvdec (Fraunhofer vvdec).
 * For IAMF: requires FFmpeg built with --enable-libiamf.
 * See scripts/build_ffmpeg_custom.sh for the exact build commands.
 *
 * The ffmpeg-kit-full AAR already includes libvvdec and libiamf.
 * APV requires a custom .aar replacement — swap the dependency in build.gradle.kts.
 */
class FFmpegEngine(
    private val scope: CoroutineScope,
    private val onFrameReady: (Bitmap) -> Unit,
    private val onError: (String) -> Unit,
    private val onComplete: () -> Unit,
    private val onProgress: (Double) -> Unit   // 0.0–1.0
) {
    companion object {
        private const val TAG = "FFmpegEngine"
        private const val SAMPLE_RATE = 48000
        private const val CHANNELS = 2          // stereo downmix; extend for surround
        private const val FRAME_WIDTH = 1920
        private const val FRAME_HEIGHT = 1080
    }

    private val isPlaying = AtomicBoolean(false)
    private val isPaused = AtomicBoolean(false)
    private val positionMs = AtomicLong(0L)
    private var durationMs = 0L

    private var audioTrack: AudioTrack? = null
    private var videoJob: Job? = null
    private var audioJob: Job? = null

    private var videoFifo: File? = null
    private var audioFifo: File? = null

    // ── Public API ──────────────────────────────────────────────────────────

    fun play(filePath: String) {
        if (isPlaying.getAndSet(true)) return
        isPaused.set(false)
        probeDuration(filePath)
        startPipeline(filePath)
    }

    fun pause() { isPaused.set(true) }
    fun resume() { isPaused.set(false) }
    fun isPlaying(): Boolean = isPlaying.get() && !isPaused.get()

    fun seekTo(ms: Long) {
        // Re-launch pipeline from seek point
        // Implementation: stop current session, restart with -ss <ms/1000>
        positionMs.set(ms)
    }

    fun release() {
        isPlaying.set(false)
        FFmpegKit.cancel()
        videoJob?.cancel()
        audioJob?.cancel()
        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
        videoFifo?.delete()
        audioFifo?.delete()
    }

    fun getDurationMs(): Long = durationMs
    fun getPositionMs(): Long = positionMs.get()

    // ── Probe ────────────────────────────────────────────────────────────────

    private fun probeDuration(path: String) {
        val session = FFprobeKit.getMediaInformation(path)
        val info = session.mediaInformation ?: return
        durationMs = ((info.duration?.toDoubleOrNull() ?: 0.0) * 1000).toLong()
        Log.d(TAG, "Duration: ${durationMs}ms | Format: ${info.format}")
        logStreamInfo(info)
    }

    private fun logStreamInfo(info: com.arthenica.ffmpegkit.MediaInformation) {
        info.streams?.forEach { stream ->
            Log.d(TAG, "Stream [${stream.index}] codec=${stream.codec} " +
                    "type=${stream.type} ${stream.sampleRate ?: stream.width}x${stream.height ?: ""}")
        }
    }

    // ── Pipeline ─────────────────────────────────────────────────────────────

    /**
     * Launch parallel video-decode and audio-decode jobs.
     *
     * Video pipeline:
     *   FFmpeg → rawvideo (rgba) → named pipe → read Bitmaps → SurfaceView
     *
     * Audio pipeline:
     *   FFmpeg → pcm_s16le → named pipe → AudioTrack
     */
    private fun startPipeline(filePath: String) {
        val videoPipe = FFmpegKitConfig.registerNewFFmpegPipe(null)
        val audioPipe = FFmpegKitConfig.registerNewFFmpegPipe(null)
        videoFifo = File(videoPipe)
        audioFifo = File(audioPipe)

        val fps = probeVideoFps(filePath)
        val (width, height) = probeVideoDimensions(filePath)
        val frameDelay = (1000L / fps).coerceAtLeast(16L)

        // ── Video decode job ──────────────────────────────────────────────
        videoJob = scope.launch(Dispatchers.IO) {
            /*
             * -vf scale flags ensure proper chroma, -pix_fmt rgba for Bitmap.
             * For VVC files, libvvdec is used automatically when codec=vvc.
             * For APV files, libapv is used automatically when codec=apv.
             */
            val videoCmd = buildString {
                append("-i \"$filePath\" ")
                append("-an ")                                   // no audio in this pipe
                append("-vf scale=${width}:${height}:flags=bicubic ")
                append("-pix_fmt rgba ")
                append("-f rawvideo ")
                append("-r $fps ")
                append("\"$videoPipe\"")
            }

            Log.d(TAG, "Video cmd: $videoCmd")

            val frameBytes = width * height * 4           // RGBA
            val buffer = ByteBuffer.allocateDirect(frameBytes)
            val byteArray = ByteArray(frameBytes)

            FFmpegKit.executeAsync(videoCmd) { session ->
                val rc = session.returnCode
                if (!ReturnCode.isSuccess(rc)) {
                    val log = session.allLogsAsString
                    Log.e(TAG, "Video decode failed: $log")
                    onError("Video decode failed.\n\n$log")
                }
            }

            try {
                val stream = videoFifo!!.inputStream().buffered(frameBytes * 4)
                var frameCount = 0L
                while (isPlaying.get() && !currentCoroutineContext().job.isCancelled) {
                    while (isPaused.get()) delay(50)

                    val bytesRead = stream.readNBytes(byteArray, 0, frameBytes)
                    if (bytesRead < frameBytes) break

                    buffer.clear()
                    buffer.put(byteArray)
                    buffer.rewind()

                    val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(buffer)
                    onFrameReady(bmp)

                    frameCount++
                    positionMs.set((frameCount * frameDelay))
                    val progress = if (durationMs > 0) positionMs.get().toDouble() / durationMs else 0.0
                    onProgress(progress)

                    delay(frameDelay)
                }
                stream.close()
            } catch (e: Exception) {
                Log.e(TAG, "Video pipe read error", e)
            }

            if (isPlaying.get()) {
                isPlaying.set(false)
                withContext(Dispatchers.Main) { onComplete() }
            }
        }

        // ── Audio decode job ──────────────────────────────────────────────
        audioJob = scope.launch(Dispatchers.IO) {
            initAudioTrack()
            /*
             * -ac 2 downmix to stereo (IAMF can be multi-channel; extend -ac / layout as needed)
             * -ar 48000 resample to device-friendly rate
             * aformat filter ensures consistent PCM output for all input types (IAMF, AAC, etc.)
             */
            val audioCmd = buildString {
                append("-i \"$filePath\" ")
                append("-vn ")
                append("-af \"aformat=sample_fmts=s16:channel_layouts=stereo:sample_rates=$SAMPLE_RATE\" ")
                append("-f s16le ")
                append("\"$audioPipe\"")
            }

            Log.d(TAG, "Audio cmd: $audioCmd")

            FFmpegKit.executeAsync(audioCmd) { session ->
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    Log.e(TAG, "Audio decode: ${session.allLogsAsString}")
                }
            }

            try {
                val track = audioTrack ?: return@launch
                val chunk = ByteArray(4096)
                val stream = audioFifo!!.inputStream().buffered(65536)
                track.play()

                while (isPlaying.get() && !currentCoroutineContext().job.isCancelled) {
                    while (isPaused.get()) {
                        track.pause()
                        delay(50)
                        if (!isPaused.get()) track.play()
                    }
                    val n = stream.read(chunk)
                    if (n < 0) break
                    track.write(chunk, 0, n)
                }
                stream.close()
                track.stop()
            } catch (e: Exception) {
                Log.e(TAG, "Audio pipe read error", e)
            }
        }
    }

    // ── Audio track init ──────────────────────────────────────────────────────

    private fun initAudioTrack() {
        val bufSize = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(65536)

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(bufSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    }

    // ── Probe helpers ─────────────────────────────────────────────────────────

    private fun probeVideoFps(path: String): Long {
        val session = FFprobeKit.execute(
            "-v quiet -select_streams v:0 -show_entries stream=r_frame_rate -of csv=p=0 \"$path\""
        )
        return try {
            val raw = session.output.trim()          // e.g. "30000/1001" or "25/1"
            val parts = raw.split("/")
            if (parts.size == 2) (parts[0].toLong() / parts[1].toLong()).coerceIn(1, 120)
            else 30L
        } catch (e: Exception) { 30L }
    }

    private fun probeVideoDimensions(path: String): Pair<Int, Int> {
        val session = FFprobeKit.execute(
            "-v quiet -select_streams v:0 -show_entries stream=width,height -of csv=p=0 \"$path\""
        )
        return try {
            val parts = session.output.trim().split(",")
            val w = parts[0].toInt().coerceIn(1, 7680)
            val h = parts[1].toInt().coerceIn(1, 4320)
            Pair(w, h)
        } catch (e: Exception) { Pair(FRAME_WIDTH, FRAME_HEIGHT) }
    }
}
