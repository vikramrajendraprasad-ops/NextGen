package com.nextgen.player

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.nextgen.player.databinding.ActivityMainBinding
import com.nextgen.player.engine.CodecInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // ── File picker ─────────────────────────────────────────────────────────
    private val filePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        val realPath = getRealPath(uri) ?: run {
            Toast.makeText(this, "Cannot resolve file path from URI", Toast.LENGTH_SHORT).show()
            return@registerForActivityResult
        }
        openPlayer(realPath)
    }

    // ── Permission request ───────────────────────────────────────────────────
    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) filePicker.launch("video/*")
        else Toast.makeText(this, "Storage permission required", Toast.LENGTH_SHORT).show()
    }

    // ── onCreate ─────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnOpenFile.setOnClickListener { checkPermissionAndPick() }
        binding.btnOpenAny.setOnClickListener {
            // Open */* to allow .apv / .iamf files not exposed as video/*
            checkPermissionAndPickAny()
        }

        // Probe codec support in background
        binding.tvCodecStatus.text = "Checking codec support…"
        lifecycleScope.launch {
            val support = withContext(Dispatchers.IO) { CodecInfo.query() }
            binding.tvCodecStatus.text = CodecInfo.statusText(support)
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun checkPermissionAndPick() {
        val perms = requiredPermissions()
        if (perms.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            filePicker.launch("video/*")
        } else {
            permLauncher.launch(perms.toTypedArray())
        }
    }

    private fun checkPermissionAndPickAny() {
        val perms = requiredPermissions()
        if (perms.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            filePicker.launch("*/*")
        } else {
            permLauncher.launch(perms.toTypedArray())
        }
    }

    private fun requiredPermissions(): List<String> = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ->
            listOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else ->
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun getRealPath(uri: Uri): String? {
        // Try content resolver first (works for most file managers)
        if (uri.scheme == "file") return uri.path

        try {
            contentResolver.query(uri, arrayOf(MediaStore.Video.Media.DATA), null, null, null)
                ?.use { cursor ->
                    val col = cursor.getColumnIndex(MediaStore.Video.Media.DATA)
                    if (cursor.moveToFirst() && col >= 0) return cursor.getString(col)
                }
        } catch (_: Exception) { }

        // Fallback: copy to cache for access
        return try {
            val name = contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val col = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && col >= 0) cursor.getString(col) else "video_tmp"
            } ?: "video_tmp"

            val tmpFile = java.io.File(cacheDir, name)
            contentResolver.openInputStream(uri)?.use { ins ->
                tmpFile.outputStream().use { out -> ins.copyTo(out) }
            }
            tmpFile.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    private fun openPlayer(path: String) {
        val intent = Intent(this, PlayerActivity::class.java)
        intent.putExtra(PlayerActivity.EXTRA_FILE_PATH, path)
        startActivity(intent)
    }
}
