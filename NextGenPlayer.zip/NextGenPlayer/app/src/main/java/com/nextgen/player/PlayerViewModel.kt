package com.nextgen.player

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.nextgen.player.engine.FFmpegEngine

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    val currentFrame  = MutableLiveData<Bitmap?>()
    val isPlaying     = MutableLiveData(false)
    val progressFrac  = MutableLiveData(0.0)     // 0.0 – 1.0
    val errorMessage  = MutableLiveData<String?>()
    val playbackDone  = MutableLiveData(false)

    private var engine: FFmpegEngine? = null

    fun load(filePath: String) {
        engine?.release()
        playbackDone.postValue(false)
        errorMessage.postValue(null)

        engine = FFmpegEngine(
            scope       = viewModelScope,
            onFrameReady = { bmp ->
                currentFrame.postValue(bmp)
                isPlaying.postValue(true)
            },
            onError    = { msg -> errorMessage.postValue(msg) },
            onComplete = {
                isPlaying.postValue(false)
                playbackDone.postValue(true)
            },
            onProgress = { frac -> progressFrac.postValue(frac) }
        )
        engine!!.play(filePath)
        isPlaying.postValue(true)
    }

    fun togglePause() {
        val eng = engine ?: return
        if (eng.isPlaying()) {
            eng.pause()
            isPlaying.postValue(false)
        } else {
            eng.resume()
            isPlaying.postValue(true)
        }
    }

    fun seekTo(frac: Double) {
        val durationMs = engine?.getDurationMs() ?: return
        engine?.seekTo((frac * durationMs).toLong())
    }

    fun getDurationMs(): Long = engine?.getDurationMs() ?: 0L

    override fun onCleared() {
        super.onCleared()
        engine?.release()
    }
}
