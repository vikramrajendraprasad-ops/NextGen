# NextGen Player – APV · VVC (H.266) · IAMF

Android video/audio player that plays formats not supported by Android's MediaCodec.
Uses **FFmpeg software decoding**, so it works on all Android 7+ devices without hardware support.

---

## Supported Formats

| Format | Standard | Decoder | Status |
|--------|----------|---------|--------|
| APV    | Advanced Professional Video (Samsung, 2024) | libapv | Custom build needed |
| VVC    | H.266 / Versatile Video Coding (ITU-T) | libvvdec | Included in ffmpeg-kit-full |
| IAMF   | Immersive Audio Model and Formats (AOM) | libiamf | Included in ffmpeg-kit-full |

---

## Quick Start (VVC + IAMF only)

`ffmpeg-kit-full` already ships with libvvdec and libiamf. To get started immediately:

```
1. Open in Android Studio (Electric Eel or newer)
2. Sync Gradle
3. Run on device (Android 7+ / API 24+)
```

VVC and IAMF will work out of the box.

---

## APV Support (Custom FFmpeg Build)

APV requires a custom FFmpeg build with Samsung's **libapv**.

```bash
# Prerequisites: Ubuntu 22.04, Android NDK r26b, CMake 3.22+, Ninja
export ANDROID_NDK_HOME=~/android-ndk-r26b
chmod +x scripts/build_ffmpeg_custom.sh
./scripts/build_ffmpeg_custom.sh
```

The script:
1. Builds **vvdec** (VVC decoder by Fraunhofer HHI)
2. Builds **libiamf** (IAMF decoder by Alliance for Open Media)
3. Builds **libapv** (APV decoder by Samsung)
4. Compiles FFmpeg with all three linked in

After the build, follow the on-screen instructions to package the AAR and replace the
`ffmpeg-kit-full` dependency in `app/build.gradle.kts`.

---

## Architecture

```
File (APV/VVC/IAMF)
        │
        ├── FFmpegEngine.kt
        │       ├── Video pipe: FFmpeg → rawvideo RGBA → named pipe → Bitmap → ImageView
        │       └── Audio pipe: FFmpeg → PCM s16le → named pipe → AudioTrack
        │
        ├── PlayerViewModel.kt  (state + lifecycle)
        └── PlayerActivity.kt   (fullscreen UI, controls, seek)
```

### Why named pipes?
Android's MediaCodec has no support for APV/VVC/IAMF. FFmpeg pipes decoded raw
frames/audio to the app in real-time — the same approach as the Termux FFmpeg
player, just wrapped in an Android Activity.

---

## Notes

- **Performance**: Software decoding is CPU-intensive. 4K VVC on mid-range phones
  may drop frames. Use lower resolutions for smooth playback or consider
  hardware-accelerated VVC once Android adds MediaCodec support (expected ~2026).
- **IAMF audio**: Currently downmixed to stereo for `AudioTrack`. Extend
  `FFmpegEngine.CHANNELS` and the `aformat` filter for 5.1/7.1 output.
- **Seek**: Full seek support requires pipeline restart with `-ss`. The seek
  skeleton in `FFmpegEngine.seekTo()` is ready to extend.
- **Min SDK**: API 24 (Android 7.0). AudioTrack.Builder requires API 23+.

---

## File Extensions Recognized

`.apv`, `.266`, `.vvc`, `.h266`, `.iamf`, `.oa4`, `.mp4` (with APV/VVC track),
`.mkv`, `.ts`, `.m2ts`
