#!/usr/bin/env bash
# =============================================================================
# build_ffmpeg_custom.sh
# Builds a custom FFmpeg for Android with APV, VVC (vvdec), and IAMF support.
#
# Output: ffmpeg-kit-custom.aar  (replace ffmpeg-kit-full in build.gradle.kts)
#
# Requirements:
#   - Linux host (Ubuntu 22.04 recommended)
#   - Android NDK r26b (set ANDROID_NDK_HOME below)
#   - CMake 3.22+, Ninja, NASM, autoconf, automake, libtool
#
# Usage:
#   chmod +x build_ffmpeg_custom.sh
#   ./build_ffmpeg_custom.sh
# =============================================================================

set -e

# ── Configuration ────────────────────────────────────────────────────────────
ANDROID_NDK_HOME="${ANDROID_NDK_HOME:-$HOME/android-ndk-r26b}"
MIN_SDK=24
TARGET_ABI="arm64-v8a"      # Change to "armeabi-v7a" or "x86_64" as needed
BUILD_DIR="$HOME/ffmpeg_build"
SYSROOT="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/sysroot"
TOOLCHAIN="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64"
CLANG_PREFIX="${TOOLCHAIN}/bin/aarch64-linux-android${MIN_SDK}"

mkdir -p "$BUILD_DIR/libs" "$BUILD_DIR/install"

echo "=== Build dir: $BUILD_DIR ==="
echo "=== NDK: $ANDROID_NDK_HOME ==="

# ── 1. Build vvdec (H.266 / VVC decoder by Fraunhofer HHI) ──────────────────
echo ""
echo ">>> [1/3] Building vvdec (VVC decoder)..."
cd "$BUILD_DIR"
if [ ! -d vvdec ]; then
    git clone --depth 1 https://github.com/fraunhoferhhi/vvdec.git
fi
cd vvdec
mkdir -p build_android && cd build_android
cmake .. \
    -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$TARGET_ABI" \
    -DANDROID_PLATFORM="android-${MIN_SDK}" \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX="$BUILD_DIR/install" \
    -DBUILD_SHARED_LIBS=OFF \
    -DVVDEC_ENABLE_LINK_TIME_OPT=OFF \
    -GNinja
ninja -j$(nproc)
ninja install
echo ">>> vvdec done."

# ── 2. Build libiamf (IAMF audio decoder by Google/Alliance for Open Media) ──
echo ""
echo ">>> [2/3] Building libiamf (IAMF audio)..."
cd "$BUILD_DIR"
if [ ! -d libiamf ]; then
    git clone --depth 1 https://github.com/AOMediaCodec/libiamf.git
fi
cd libiamf
mkdir -p build_android && cd build_android
cmake .. \
    -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$TARGET_ABI" \
    -DANDROID_PLATFORM="android-${MIN_SDK}" \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX="$BUILD_DIR/install" \
    -DBUILD_SHARED_LIBS=OFF \
    -GNinja
ninja -j$(nproc)
ninja install
echo ">>> libiamf done."

# ── 3. Build libapv (Samsung Advanced Professional Video) ───────────────────
echo ""
echo ">>> [3/3a] Building libapv (APV decoder)..."
cd "$BUILD_DIR"
if [ ! -d libapv ]; then
    # Samsung open-sourced libapv in 2024
    git clone --depth 1 https://github.com/Samsung/libapv.git
fi
cd libapv
mkdir -p build_android && cd build_android
cmake .. \
    -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$TARGET_ABI" \
    -DANDROID_PLATFORM="android-${MIN_SDK}" \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX="$BUILD_DIR/install" \
    -DBUILD_SHARED_LIBS=OFF \
    -GNinja
ninja -j$(nproc)
ninja install
echo ">>> libapv done."

# ── 4. Build FFmpeg with all three libraries ─────────────────────────────────
echo ""
echo ">>> [3/3b] Building FFmpeg with APV + VVC + IAMF..."
cd "$BUILD_DIR"
if [ ! -d ffmpeg ]; then
    git clone --depth 1 https://github.com/FFmpeg/FFmpeg.git ffmpeg
fi
cd ffmpeg

export CC="${CLANG_PREFIX}-clang"
export CXX="${CLANG_PREFIX}-clang++"
export AR="${TOOLCHAIN}/bin/llvm-ar"
export RANLIB="${TOOLCHAIN}/bin/llvm-ranlib"
export STRIP="${TOOLCHAIN}/bin/llvm-strip"
export NM="${TOOLCHAIN}/bin/llvm-nm"
export PKG_CONFIG_PATH="$BUILD_DIR/install/lib/pkgconfig"

./configure \
    --prefix="$BUILD_DIR/install/ffmpeg" \
    --enable-cross-compile \
    --cross-prefix="${TOOLCHAIN}/bin/aarch64-linux-android-" \
    --arch=aarch64 \
    --cpu=armv8-a \
    --target-os=android \
    --sysroot="$SYSROOT" \
    --cc="$CC" \
    --cxx="$CXX" \
    --ar="$AR" \
    --ranlib="$RANLIB" \
    --strip="$STRIP" \
    --nm="$NM" \
    \
    --enable-static \
    --disable-shared \
    --disable-programs \
    --disable-doc \
    --disable-debug \
    --enable-optimizations \
    \
    --enable-jni \
    --enable-mediacodec \
    --enable-neon \
    \
    --enable-libvvdec \
    --enable-libiamf \
    --enable-libapv \
    \
    --extra-cflags="-I$BUILD_DIR/install/include -fPIC -fno-limit-debug-info" \
    --extra-ldflags="-L$BUILD_DIR/install/lib" \
    \
    --enable-decoder=libvvdec \
    --enable-decoder=libiamf \
    --enable-decoder=apv \
    \
    --enable-demuxer=iamf \
    --enable-muxer=iamf \
    \
    --disable-encoders \
    --enable-encoder=pcm_s16le \
    \
    2>&1 | tee "$BUILD_DIR/ffmpeg_configure.log"

make -j$(nproc)
make install

echo ""
echo "=== FFmpeg build complete ==="
echo "Output: $BUILD_DIR/install/ffmpeg"
echo ""
echo "Next steps:"
echo "  1. Copy the .a files into your ffmpeg-kit fork's jni/libs/$TARGET_ABI/"
echo "  2. Update ffmpeg-kit CMakeLists to link libvvdec, libiamf, libapv"
echo "  3. Build the AAR:  cd ffmpeg-kit && ./android.sh --full"
echo "  4. Replace implementation(libs.ffmpeg-kit-full) in app/build.gradle.kts"
echo "     with: implementation(files('../libs/ffmpeg-kit-custom-$TARGET_ABI.aar'))"
