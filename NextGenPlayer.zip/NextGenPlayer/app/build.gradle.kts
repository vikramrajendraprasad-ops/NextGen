plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.nextgen.player"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nextgen.player"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        ndk {
            // ffmpeg-kit ships arm64-v8a, armeabi-v7a, x86_64
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        viewBinding = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        // ffmpeg-kit includes native libs – avoid duplicate .so conflicts
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.androidx.lifecycle.viewmodel)

    // ffmpeg-kit-full: includes libvvdec (VVC/H.266), libiamf, and most other codecs.
    // For APV support, replace with your custom .aar built with libapv — see scripts/build_ffmpeg_custom.sh
    // Maven: https://github.com/arthenica/ffmpeg-kit
    implementation(libs.ffmpeg-kit-full)
}
