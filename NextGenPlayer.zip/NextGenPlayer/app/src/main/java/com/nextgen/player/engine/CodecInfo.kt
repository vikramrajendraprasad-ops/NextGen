package com.nextgen.player.engine

import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig

/**
 * Reports which next-gen codecs are available in the loaded FFmpeg binary.
 *
 * APV   – Samsung Advanced Professional Video (requires custom build with libapv)
 * VVC   – H.266 / Versatile Video Coding (requires --enable-libvvdec; included in ffmpeg-kit-full)
 * IAMF  – Immersive Audio Model and Formats  (requires --enable-libiamf; included in ffmpeg-kit-full)
 */
data class CodecSupport(
    val apv: Boolean,
    val vvc: Boolean,
    val iamf: Boolean,
    val ffmpegVersion: String
)

object CodecInfo {

    fun query(): CodecSupport {
        var apv = false
        var vvc = false
        var iamf = false
        var version = "unknown"

        // -codecs outputs all encoder/decoder names
        val codecSession = FFmpegKit.execute("-codecs -hide_banner")
        val codecOutput = codecSession.allLogsAsString ?: ""

        apv  = codecOutput.contains("apv",  ignoreCase = true)
        vvc  = codecOutput.contains("vvc",  ignoreCase = true) ||
               codecOutput.contains("libvvdec", ignoreCase = true)
        iamf = codecOutput.contains("iamf", ignoreCase = true) ||
               codecOutput.contains("libiamf", ignoreCase = true)

        // Version string
        val verSession = FFmpegKit.execute("-version -hide_banner")
        val verOutput = verSession.allLogsAsString ?: ""
        val versionLine = verOutput.lines().firstOrNull { it.startsWith("ffmpeg version") }
        version = versionLine?.substringAfter("version ")?.substringBefore(" ")?.trim() ?: "unknown"

        return CodecSupport(apv = apv, vvc = vvc, iamf = iamf, ffmpegVersion = version)
    }

    /** Returns human-readable status string for the UI */
    fun statusText(support: CodecSupport): String = buildString {
        appendLine("FFmpeg ${support.ffmpegVersion}")
        appendLine()
        appendLine("APV  (Advanced Professional Video) : ${if (support.apv)  "✅ Supported" else "⚠️  Needs custom build (libapv)"}")
        appendLine("VVC  (H.266 / Versatile Video)     : ${if (support.vvc)  "✅ Supported" else "⚠️  Needs libvvdec build"}")
        append(    "IAMF (Immersive Audio)              : ${if (support.iamf) "✅ Supported" else "⚠️  Needs libiamf build"}")
    }

    /**
     * Map file extension to likely codec type for UI display.
     */
    fun describeFile(path: String): String {
        val ext = path.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "apv"                  -> "APV – Advanced Professional Video"
            "266", "vvc", "h266"   -> "VVC – H.266 Versatile Video Coding"
            "iamf", "oa4"          -> "IAMF – Immersive Audio"
            "mp4", "mov"           -> "MP4 Container (may contain APV/VVC/IAMF)"
            "mkv", "webm"          -> "Matroska/WebM Container"
            "ts", "mts", "m2ts"    -> "MPEG-TS"
            else                   -> "Media file (.$ext)"
        }
    }
}
